/////////////////////////////////////////////////////////////////////////////
// Name:        class_menus.h
// Purpose:     Menu classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_menus Menus
@ingroup group_class

Group of classes for handling menu bars and items.

*/

