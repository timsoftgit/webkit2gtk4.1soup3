Files in this subdirectory were taken from the [Doxygen Awesome][1] CSS theme
and are under MIT licence.

[1]: https://github.com/jothepro/doxygen-awesome-css
