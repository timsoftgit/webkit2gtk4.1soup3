class MessageDialog:
    def __init__(
            self,
            parent,
            title="Warning",
            message="An error has occurred.",
            log=False
    ):
        parent = _
        title = _
        log = _
        print(message)
