# Help translating Bottles :rocket:
Help Bottles get translated in your language!

## Improve a translation :raising_hand:
If you've found typos or just think you can improve a translation, contribute 
using the [Weblate](https://hosted.weblate.org/engage/bottles/) platform.

Please, this is an open source, free, free project. Don't vandalize the 
translations, it's not funny, it's idiotic.

## Thanks! :two_hearts: :tada:
A heartfelt thanks to anyone who wants to help us get Bottles to speak any language!
