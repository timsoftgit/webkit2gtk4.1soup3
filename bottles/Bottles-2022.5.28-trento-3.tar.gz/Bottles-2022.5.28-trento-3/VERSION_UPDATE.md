### Paths to be updated
- VERSION
- AppimageBuilder.yml
- src/ui/about.ui
- src/params.py
- data/com.usebottles.appdata.xml.in
- debian/changelog
- src/bottles.in
- meson.build